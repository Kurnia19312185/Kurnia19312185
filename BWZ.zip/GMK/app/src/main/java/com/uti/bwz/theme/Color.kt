package com.uti.bwz.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFFD8D8D8)
val  Nav = Color(0xFFFD8F8F)
val bg = Color(0xFFFEECEC)
val bg_data = Color(0xFFA43E3E)