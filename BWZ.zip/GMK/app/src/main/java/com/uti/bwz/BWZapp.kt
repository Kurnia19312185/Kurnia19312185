package com.uti.bwz

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BWZapp : Application()